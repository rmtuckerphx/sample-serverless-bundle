const _camelCase = require('lodash.camelcase');

exports.handler = (event, context, callback) => {
    console.log('hello');
    console.log(_camelCase('hello there'));
};